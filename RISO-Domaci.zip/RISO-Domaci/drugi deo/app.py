import http.client
import json

conn = http.client.HTTPSConnection("localhost", 5000)
payload = json.dumps({
  "ime": "Anja",
  "prezime": "Ivanovic",
  "username": "aivanovic",
  "smer": "IT",
  "predmeti": [
    {
      "ime": "RISO",
      "espb": 7
    },
    {
      "ime": "RISO",
      "espb": 8
    }
  ]
})
headers = {
  'Content-Type': 'application/json'
}
conn.request("POST", "/users", payload, headers)
res = conn.getresponse()
data = res.read()
print(data.decode("utf-8"))